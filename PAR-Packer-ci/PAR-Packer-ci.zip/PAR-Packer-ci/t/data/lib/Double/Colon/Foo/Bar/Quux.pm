package Double::Colon::Foo::Bar::Quux;
1;
