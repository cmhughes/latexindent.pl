package Double::Colon;
1;
